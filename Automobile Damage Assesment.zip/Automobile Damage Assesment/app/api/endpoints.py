from fastapi import APIRouter, UploadFile, File
from model.predictor import DamagePredictor

router = APIRouter()

# Initialize the predictor
predictor = DamagePredictor(model_path="models/damage_model.pth")

@router.post("/predict/")
async def predict_damage(file: UploadFile = File(...)):
    image_bytes = await file.read()
    prediction = predictor.predict(image_bytes)
    return {"damage_severity": prediction}
