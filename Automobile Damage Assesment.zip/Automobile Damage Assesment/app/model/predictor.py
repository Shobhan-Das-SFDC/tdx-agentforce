import torch
import torchvision.transforms as transforms
from PIL import Image
from model.modelCNN import CarDamageCNN

# Load model
model = CarDamageCNN()
model.load_state_dict(torch.load("app/model/damage_model.pth", map_location=torch.device('cpu')))
model.eval()

# Transform
transform = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ToTensor()
])

def get_damage_prediction(image_path):
    image = Image.open(image_path).convert('RGB')
    image = transform(image).unsqueeze(0)

    with torch.no_grad():
        output = model(image)
        probabilities = torch.softmax(output, dim=1)[0]

    confidence_score = round(torch.max(probabilities).item() * 100, 2)
    predicted_class = int(torch.argmax(probabilities).item())

    if predicted_class == 0:
        damage_percentage = 0
        severity = "None"
    else:

        damage_percentage = round(30 + 70 * probabilities[1].item(), 2)  
        severity = classify_severity(damage_percentage)

    return {
        "damage_percentage": damage_percentage,
        "severity": severity,
        "confidence_score": confidence_score  
    }


def classify_severity(damage_percentage):
    if damage_percentage < 30:
        return "Mild"
    elif damage_percentage < 90:
        return "Moderate"
    else:
        return "Severe"
