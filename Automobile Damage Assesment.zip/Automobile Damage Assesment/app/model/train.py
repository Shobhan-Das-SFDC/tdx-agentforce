import torch
import torch.optim as optim
import torch.nn as nn
from torch.utils.data import DataLoader
from dataset import CarDamageDataset
from model import CarDamageCNN
import torchvision.transforms as transforms

def train_model(train_csv, val_csv, image_folder, epochs=10, batch_size=32):

    transform = transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.ToTensor()
    ])

    train_dataset = CarDamageDataset(train_csv, image_folder, transform=transform)
    val_dataset = CarDamageDataset(val_csv, image_folder, transform=transform)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    model = CarDamageCNN()
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            
            optimizer.zero_grad()

            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

        train_acc = 100. * correct / total
        print(f'Epoch [{epoch+1}/{epochs}], Loss: {running_loss/len(train_loader):.4f}, Accuracy: {train_acc:.2f}%')

    # Save model
    torch.save(model.state_dict(), 'app/model/damage_model.pth')
    print('✅ Model trained and saved successfully!')

if __name__ == "__main__":
    train_model(
        train_csv='data/train_labels.csv',
        val_csv='data/val_labels.csv',
        image_folder='data/archive/CarDD_release/CarDD_SOD/CarDD-TR/CarDD-TR-Image'
    )
