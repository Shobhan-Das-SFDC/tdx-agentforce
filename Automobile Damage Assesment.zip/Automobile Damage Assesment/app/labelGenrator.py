import os
import cv2
import pandas as pd
import numpy as np

# Paths
image_folder = 'C:\\Users\\Shobhan_Das\\Downloads\\vehicle_damage_project\data\\archive\CarDD_release\\CarDD_SOD\\CarDD-VAL\\CarDD-VAL-Image'
mask_folder = 'C:\\Users\\Shobhan_Das\\Downloads\\vehicle_damage_project\data\\archive\CarDD_release\\CarDD_SOD\\CarDD-VAL\\CarDD-VAL-Mask'


# Output list
data = []

# Threshold to decide if mask is empty
THRESHOLD = 0.01  # If less than 1% pixels are white, it's considered undamaged

# Loop through images
for filename in os.listdir(image_folder):
    image_path = os.path.join(image_folder, filename)
    
    # Change filename extension from .jpg to .png
    mask_filename = os.path.splitext(filename)[0] + '.png'
    mask_path = os.path.join(mask_folder, mask_filename)

    print(f"Checking image: {image_path}")
    print(f"Expected mask: {mask_path}")

    if os.path.exists(mask_path):
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if mask is not None:
            white_pixel_ratio = np.sum(mask > 0) / (mask.shape[0] * mask.shape[1])
            label = 1 if white_pixel_ratio > THRESHOLD else 0  # 1 = Damaged, 0 = Undamaged
            data.append({'image_filename': filename, 'label': label})
        else:
            print(f"Warning: Failed to read mask for {filename}")
    else:
        print(f"Warning: Mask not found for {filename}")

# Create a DataFrame
df = pd.DataFrame(data)

# Save to CSV
df.to_csv('validation_labels.csv', index=False)

print("✅ Labeling done! Saved to 'train_labels.csv'.")
