# app/main.py

from fastapi import FastAPI, UploadFile, File
import uuid
import shutil

from model import predictor  

app = FastAPI() 

@app.post("/predict")
async def predict_damage(file: UploadFile = File(...)):

    filename = f"temp_{uuid.uuid4().hex}.jpg"
    with open(filename, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    result = predictor.get_damage_prediction(filename)
    print(result)
    return {
        "filename": file.filename,
        "damage_percentage": result["damage_percentage"],
        "severity": result["severity"],
        "confidence_score": result["confidence_score"]
    }
